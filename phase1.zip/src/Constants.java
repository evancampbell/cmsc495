
public final class Constants {
    public static final String PROJECT_ROOT = "/home/evan/eclipse-workspace/Test";
    public static final String CAPTURES_DIR = "res/captures/";
}
